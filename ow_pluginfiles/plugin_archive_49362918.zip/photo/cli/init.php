<?php

PHOTO_CLASS_EventHandler::getInstance()->genericInit();
