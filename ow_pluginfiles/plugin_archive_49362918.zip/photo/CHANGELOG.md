# Version 1.8.3 (10600)
- photo description is no longer cut due to tag presence
- added ALT HTML attribute for photo thumbs within photo widget on profile view page, as well as photo lists (latest, top rated, most discussed)
- added ALT HTML attribute for photos on separate photo view page
- added GET parameter for temporary photos to prevent caching errors

# Version 1.8.2 (10400)
- added warning message when uploaded photo is bigger than the size defined in the plugin settings;
- fixed photo thumbs display for photo widget in mobile version;
- removed duplicate photos in the list of photos on the ‘Most discussed photos’ page;

# Version 1.8.1 (10200)
- empty albums no longer show up in User Albums widget on Profile View page;
- fixed photo search by tag bug;
- fixed bugs found during display of photos on photo lists;