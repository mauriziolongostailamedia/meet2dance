# photo
Photo plugin for Oxwall. Allow users to upload photos with tags, rates, and comments.
