<?php

$eventHandler = new FBCONNECT_CLASS_EventHandler();
$eventHandler->genericInit();