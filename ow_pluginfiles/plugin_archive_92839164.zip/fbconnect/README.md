# fbconnect
Facebook Connect plugin for Oxwall. Allow users to join, sign in, and synchronize profile info using their Facebook accounts.
