# Version 1.8.3 (10600)
- blocked users no longer show up in contact list
- contact list search now displays results with partially typed-in names
- fixed bug with invitation label not disappearing in chat window
- fixed JS error “TypeError: element.input is null" appearing while switching operation modes (chat/mail/chat+mail) in plugin settings