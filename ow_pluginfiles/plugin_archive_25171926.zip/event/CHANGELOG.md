# Version 1.8.3 (10600)
- added ALT HTML attribute for event thumbs

# Version 1.8.2 (10400)
- fixed a bug allowing logged out users to edit events of other users;

# Version 1.8.1 (10200)
- only expired invitations are now deleted by cron;