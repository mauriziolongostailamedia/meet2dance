# Version 1.8.4 (10800)
- fixed integration with dailymotion.com

# Version 1.8.3 (10600)
- added ALT HTML attribute for video thumbs on video listings page

# Version 1.8.2 (10400)
- fixed the validation of video embed code during editing;