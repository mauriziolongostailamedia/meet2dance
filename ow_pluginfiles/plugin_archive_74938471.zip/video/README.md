# video
Video plugin for Oxwall. Allow users to embed videos with comments, rates, and tags.
