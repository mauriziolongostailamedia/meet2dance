# Version 1.8.3 (10600)
- added ALT HTML attribute for group thumbs