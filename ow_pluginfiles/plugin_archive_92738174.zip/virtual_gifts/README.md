# virtualgifts
Virtual Gifts plugin for Oxwall. Allow users to send private and public virtual gifts.
