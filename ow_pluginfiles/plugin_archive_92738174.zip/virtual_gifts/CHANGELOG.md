# Version 1.8.1 (10200)
- any selected gift is now shown as selected in Simplicity theme;