# Simplicity

Default theme for Oxwall core package. Absolutely required to run minimal Oxwall install.
